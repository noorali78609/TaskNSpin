
import telebot
import json
from telebot import types

BOT_TOKEN = "8064289157:AAGPE5RAUfBW63vY6WH6iZW7YTr40C5_Jjc"
bot = telebot.TeleBot(BOT_TOKEN)

# Load or initialize users.json
try:
    with open("users.json", "r") as f:
        users = json.load(f)
except:
    users = {}

def save_users():
    with open("users.json", "w") as f:
        json.dump(users, f, indent=4)

@bot.message_handler(commands=["start"])
def send_welcome(message):
    user_id = str(message.from_user.id)
    if user_id not in users:
        users[user_id] = {
            "username": message.from_user.username,
            "spins": 1,
            "earnings": 0,
            "referred_users": [],
            "referrer": None,
            "upi": "",
            "tasks": {}
        }
        save_users()

    markup = types.InlineKeyboardMarkup()
    btn = types.InlineKeyboardButton("🎮 Open TaskNSpin", web_app=types.WebAppInfo(url="https://example.com"))
    markup.add(btn)
    bot.send_message(message.chat.id, "👋 Welcome to TaskNSpin!
Complete tasks & earn real rewards!", reply_markup=markup)

bot.polling()
